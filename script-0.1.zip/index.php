<?php
use vendor\script\Session;
const SCRIPT_VERTION = "0.2";
require_once __DIR__ . '/vendor/autoload.php';
session::int();
require_once __DIR__ . '/Routes/api.php';
require_once __DIR__ . '/Routes/web.php';
