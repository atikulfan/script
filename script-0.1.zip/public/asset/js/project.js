export const url = (path = null) => {
    let baseurl = location.origin;
    baseurl = baseurl.replace("/", "");
    if (path == null || path == "") {
        baseurl += "/";
    } else {
        baseurl += "/" + path;
    }
    return baseurl;
}
export const $_GET = (name) => {
    const queryString = window.location.search;
    const urlParams = new URLSearchParams(queryString);
    if (name == "" || name == null) {
        return urlParams;
    } else {
        return urlParams.get(name) == null ? "" : urlParams.get(name);
    }
}
const boxStyle = () => {
    return {
        boxStyle: `
            background: #fff;
            padding: 10px;
            position: absolute;
            max-height: 200px;
            max-width: 400px;
            left: 0;
            right: 0;
            top: 0;
            bottom: 0;
            margin: auto;
            border-radius: 2px;
            border: 1px solid #dfdada;
            box-sizing: border-box;
            box-shadow: 0 0 3px 2px #f4efeff7;
              `,
        headline: `
            padding: 0px;
            margin: 0px;
            margin-top: 0px;
            font-size: 20px;
            margin-top: 6px;
            color: #5527f7;
            `,
        text:`
        padding: 0px;
        margin: 0px;
        font-size: 14px;
        color: #7b7a7a;
        line-height: 19px;
        `,
        buttonYes:`
        position: absolute;
        right: 0;
        bottom: 0;
        margin: 10px;
        width: 52px;
        height: 27px;
        border: 1px solid #f015b9;
        background: #ee007a;
        color: #fff;
        cursor: pointer;`,
        buttonNo:`
        position: absolute;
        right: 61px;
        bottom: 0;
        margin: 10px;
        width: 52px;
        height: 27px;
        border: 1px solid red;
        background: red;
        color: #fff;
        cursor: pointer;`,
        messeng:
        `height: 118px;
        width: 100%;
        overflow-y: auto;
        display: flex;
        justify-content: center;
        align-items: center;`
    }
}
export const box = (head,responce,yes,no,time=3000) => {
    const style = boxStyle();
    // aliment create
    const box       = document.createElement("div");
    const headline  = document.createElement("h4");
    const messeng   = document.createElement("article");
    const text      = document.createElement("p");
    const buttion   = document.createElement("button");
    const buttionNo = document.createElement("button");
    // aliment style
    box.setAttribute("style", boxStyle().boxStyle);
    headline.setAttribute("style", boxStyle().headline);
    messeng.setAttribute("style", boxStyle().messeng);
    text.setAttribute("style", boxStyle().text);
    buttion.setAttribute("style", boxStyle().buttonYes);
    buttionNo.setAttribute("style", boxStyle().buttonNo);
    document.body.style.background="#dfd8d8";

    box.append(headline);
    box.style.display
    box.append(messeng);
    messeng.append(text);
    box.append(buttion);
    box.append(buttionNo);
    headline.innerText = head;
    text.innerHTML = responce;
    buttion.innerText = "YES";
    buttionNo.innerText = "NO";
    buttion.setAttribute("onclick", `${yes}`);
    buttionNo.setAttribute("onclick", `${no}`);
    document.body.prepend(box);
    setTimeout(()=>{
        document.body.style="";
        document.body.removeChild(box);
    },time);

}

