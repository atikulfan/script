<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?= ASSET("css/bootstrap.css") ?>">
    <title>demo</title>

</head>

<body>
    <header>

    </header>

    <main class="container">
        <div class="table-responsive">
            <table class="table table-light">
                <thead>
                    <tr>
                        <th scope="col">id</th>
                        <th scope="col">Email</th>
                        <th scope="col">Password</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($datas['data'] as $data): extract($data) ?>
                        <tr>
                            <td scope="row"><?= $id ?></td>
                            <td><?= $email ?></td>
                            <td><?= $pass ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    </main>
    <footer class="container"><?php echo $datas['button'] ?></footer>
</body>

</html>