<?php


function cal(string|int|float $number, $oparetor, string|int|float $number2)
{
    if (is_numeric($number) and is_numeric($number2)) {
        $cal = null;
        switch ($oparetor) {
            case '+':
                $cal = sum($number, $number2);
                break;
            case '-':
                $cal = sub($number, $number2);
                break;
            case '*':
                $cal = mull($number, $number2);
                break;
            case '/':
                $cal = dev($number, $number2);
                break;
            default:
                $cal = sum($number, $number2);
                break;
        }
        return $cal;
    } else {
        return "Invalit number";
    }
}
function sum(string|int|float $number, string|int|float $number2)
{
    if (is_numeric($number) and is_numeric($number2)) {
        return $number + $number2;
    } else {
        return "Invalit number";
    }
}
function sub(string|int|float $number, string|int|float $number2)
{
    if (is_numeric($number) and is_numeric($number2)) {
        return $number - $number2;
    } else {
        return "Invalit number";
    }
}
function mull(string|int|float $number, string|int|float $number2)
{
    if (is_numeric($number) and is_numeric($number2)) {
        return $number * $number2;
    } else {
        return "Invalit number";
    }
}
function dev(string|int|float $number, string|int|float $number2)
{
    if (is_numeric($number) and is_numeric($number2)) {
        return $number / $number2;
    } else {
        return "Invalit number";
    }
}
function money(int|float $number)
{
    if (is_numeric($number)) {
        return number_format($number);
    } else {
        return "Invalit number";
    }

}
function bdnumber(int $i)
{
    $bdnumber = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
    return $bdnumber[$i];
}
function ennumber(int $i)
{
    $number = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
    return $number[$i];
}
function bd_number(int $number)
{
    if (is_numeric($number)) {
        $number = "$number";
        $number_array = str_split($number, 1);
        $number_size = strlen($number);
        $output = 0;
        for ($i = 0; $i < $number_size; $i++) {
            $output .= bdnumber($number_array[$i]);
        }
        $output = ltrim($output, "0");
        return $output;
    }
    return "Invalit number";
}
