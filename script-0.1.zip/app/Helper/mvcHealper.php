<?php
use vendor\script\DB;
use vendor\script\Table;

function includeController()
{
    $db = new DB;
    $modelfilepath = "app/controller/Controller.php";
    $alldata = $db->Read("controller");
    if (!empty($alldata) and count($alldata) > 0) {
        $fileRequest = "<?php ";
        foreach ($alldata as $datas) {
            $document = $datas->document;
            $fileRequest .= $document;
        }
        if ($fileRequest !== "") {
            $modelFileEdete = fopen($modelfilepath, 'w');
            fwrite($modelFileEdete, $fileRequest);
            fclose($modelFileEdete);
        }
    }
}
function setDbController(string $ControllerName)
{
    $offlineDatabase = new DB();
    $name = "$ControllerName"."Controller.php";
    $document = "require_once '".$name."';";
    $alldata = $offlineDatabase->Read('controller');
    if (!empty($alldata) and count($alldata) > 0) {
        for ($i = 0; $i < count($alldata); $i++) {
            $filename = $alldata[$i]->document;
            if ($filename !== $document) {
                if ($i == 0) {
                    $offlineDatabase->Insert("controller", ['id' => ID(), 'document' => $document]);
                }
            }
        }
    } else {
        $offlineDatabase->Insert("controller", ['id' => ID(), 'document' => $document]);
    }
}
function ControllerCreate(string $name, string $mode = "b")
{
    $baseName = $name;
    $curd = ['Index', 'Select', 'TableCreate', 'Create', 'Update', 'Delete'];
    $basic = ['Index'];
    $funcitons = $mode == "b" ? $basic : $curd;
    $name = $name . "Controller";
    $path = "app/controller/$name.php";
    $globals = 'private $column =["id" => "int(255) PRIMARY KEY AUTO_INCREMENT","userId" => "varchar(15)"];';
    $globals2 = ' private $tablenames = "'.$baseName.'";';
    $funcitonsInsert = 'e_(array_to_json($this->success));';
    $funcitonsCode = null;
    for ($i = 0; $i < count($funcitons); $i++) {
        $funcName = $funcitons[$i];
        $funcitonsCode .= "public function $funcName(){
          //your code
          $funcitonsInsert
        }";
    }
    $code = "<?php
      class $name extends BaseController{
          $globals
          $globals2
          $funcitonsCode
      }";
    if (!file_exists($path)) {
        $NewController = fopen($path, "w");
        fwrite($NewController, $code);
        fclose($NewController);
        setDbController($baseName);
        includeController();
    }
}
function ViewCreate(string $name)
{
    $code = '
      <!DOCTYPE html>
      <html lang="en">
          <head>
              <meta charset="UTF-8">
              <meta name="viewport" content="width=device-width, initial-scale=1.0">
              <title>Document</title>
          </head>
          <body>
              ' . $name . '
          </body>
      </html>';
    $path = "resource/views/$name.view.php";
    if (!file_exists($path)) {
        $viewCreate = fopen($path, 'w');
        fwrite($viewCreate, $code);
        fclose($viewCreate);
    }
}
function MVC(string $name, string $tablenames = null, array $colum = null)
{
    ControllerCreate($name, 'c');
    ViewCreate($name);
    if (!$tablenames == null) {
        $Table = new Table($tablenames);
        $Table->create($colum);
    }

}