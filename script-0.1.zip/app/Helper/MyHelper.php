<?php
use vendor\script\Session;

const EXTANTION = 1;
const NAME = 0;
const HA = true;
const NA = false;
const YES = true;
const NO = false;
const ZERO = 0;
const ONE = 1;
const TWO = 2;
const THRRE = 3;
const FORE = 4;
const FIVE = 5;
const SIX = 6;
const ON = true;
const OFF = false;
const RESPONCE = 'responce';
function ID()
{
    return substr(uniqid(), 7, 10) . rand(0, 10000000000);
}

function FILE_INFO(string $name, int $get)
{
    if (isset($name) == YES) {
        return explode(".", $name)[$get];
    }
}
function BR($value)
{
    if (isset($value) == YES) {
        echo "<pre>";
        print_r($value);
        echo "</pre>";
    }
}

function AJAX_COME($Boolean)
{
    if ($Boolean == YES) {
        return require_once("vendor/script/jsScript.php");
    }
}

function NOW()
{
    return date("d-m-Y", time());
}

function Setinfo($name, $messenge)
{
    if (isset($messenge) and isset($name)) {
        Session::set($name, $messenge);
    }
}
function Getinfo($name)
{
    if (isset($name)) {
        Session::get($name);
    }
}
function setTitle($title)
{
    if ($title != "") {
        Session::set("app_title", $title);
    }
}
function getTitle()
{
    return Session::get("app_title");
}
function setContent($name, $code)
{
    if (!empty($code) and $name != "") {
        Session::set($name, $code);
    }
}
function getContent($name)
{
    if ($name != "") {
        return Session::get($name);
    }
}

// validation healop
function mailCheck(string $text)
{
    if (str_contains($text, '@')) {
        $arry = explode('@', $text);
        return $arry[1] == "gmail.com" ? true : false;
    }
    return false;
}
function numberCheck(string $number){
    is_numeric($number)?true:false;
}

function array_to_json(array $arry){
    return json_encode($arry);
}
function json_to_Array($object){
    return json_decode($object);
}

function request_url(){
    return $_SERVER['REQUEST_URI'];
}

// ============CONTROLLER CREATE FUNCITONS ==================================
